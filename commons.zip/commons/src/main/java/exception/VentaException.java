/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exception;

/**
 *
 * @author crist
 */
public class VentaException extends Exception {
    public VentaException(String mensaje) {
        super(mensaje);
    }
}

