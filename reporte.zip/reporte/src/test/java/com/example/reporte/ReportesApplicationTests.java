package com.example.reporte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest(classes = ReportesApplication.class)
class ReportesApplicationTests {

    @Test
    void contextLoads() {
    }
}
