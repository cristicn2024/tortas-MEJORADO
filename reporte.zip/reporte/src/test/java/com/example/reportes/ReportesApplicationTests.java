package com.example.reportes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class ReportesApplicationTests {
	@Test
	void contextLoads() {
	}
}
