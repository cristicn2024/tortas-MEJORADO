package com.example.servicio_conversion_moneda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioConversionMonedaApplicationTests {

	@Test
	void contextLoads() {
	}

}
